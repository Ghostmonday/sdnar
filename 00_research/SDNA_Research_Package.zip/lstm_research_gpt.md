# LSTM Baseline Research Documentation

## 1. Architecture Specification

- **Input Features**:
  - Close price
  - Returns (log returns or simple returns)
  - Volatility (e.g., rolling standard deviation)
  - Lagged label values (previous 1‑2 days) to capture regime persistence
  - Optional engineered features: moving averages, RSI, MACD, etc.
- **Sequence Length**: Experiment with look‑back windows of **20, 60, and 120** time steps. The final choice should balance predictive power and computational cost.
- **Network Structure**:
  - Input layer matching the number of features.
  - One or two LSTM layers (e.g., 64‑128 units each) with `return_sequences=True` for stacked LSTMs.
  - Optional **Bidirectional** LSTM for richer temporal context.
  - Dense (fully‑connected) layers (e.g., 32‑64 units) after the LSTM stack.
  - **Activation Functions**: `tanh` for LSTM gates (default), `relu` for dense layers.
- **Output Layer**:
  - **Classification** (3‑class) → Softmax with three outputs (1, 0, -1).
  - **Regression** (continuous) → Linear activation if you prefer predicting the raw label value.
- **Regularization**:
  - Dropout (0.2‑0.5) after LSTM layers.
  - L2 weight decay (e.g., 1e‑4).
  - Batch Normalization (optional) on dense layers.

## 2. Training Protocol

- **Data Split**:
  - **Walk‑forward** (expanding window) split: initial training window (e.g., first 60% of observations), then sequentially expand the training set and evaluate on the next out‑of‑sample block (e.g., next 20%).
  - Ensure **no look‑ahead bias** – the model never sees future data.
- **Optimizer**: Adam with an initial learning rate of **1e‑3**. Consider a learning‑rate scheduler (reduce on plateau).
- **Loss Function**:
  - Classification → `CategoricalCrossentropy` (use class weights to address imbalance).
  - Regression → `MeanSquaredError`.
- **Batch Size**: 32‑64 (depends on GPU memory).
- **Epochs**: Up to 100 with **early stopping** (patience = 10) based on validation loss.
- **Class Imbalance Handling**: Compute class frequencies and set `class_weight` accordingly, or use focal loss.

## 3. Walk‑Forward Validation

- **Expanding Window**:
  1. Train on first _T_ observations.
  2. Predict the next _H_ observations (e.g., 20‑day horizon).
  3. Expand the training set to include the just‑predicted block and repeat.
- **Retraining Frequency**: Every **20‑day** block (or whenever a regime shift is detected).
- **Aggregation**: Concatenate all out‑of‑sample predictions to compute overall performance metrics.

## 4. Evaluation Framework

- **Classification Metrics**:
  - Precision, Recall, F1‑score per class.
  - Macro‑averaged F1.
  - AUC‑ROC (one‑vs‑rest) for each class.
- **Regression Metrics**:
  - RMSE (primary, to compare against Random Walk RMSE).
  - MAE.
  - Directional Accuracy (sign of prediction vs actual).
- **Statistical Test**:
  - **Diebold‑Mariano (DM) test** comparing LSTM RMSE against the Random Walk baseline for each asset.
  - Significance threshold **p < 0.05**.
- **Baseline Comparison**:
  - Random Walk RMSE: SPY = 4.54, BTC = 1322.
  - Random Walk Directional Accuracy ≈ 50%.

## 5. Implementation Guidance

- **Framework**: Choose **TensorFlow/Keras** (high‑level API) or **PyTorch** (flexible). Both support LSTM layers and GPU acceleration.
- **Data Pipeline**:

  ```python
  import pandas as pd
  import numpy as np
  from sklearn.preprocessing import StandardScaler

  def load_data(path):
      df = pd.read_csv(path)
      # Ensure columns: Close, volatility, label
      return df

  def create_sequences(df, seq_len, feature_cols, target_col='label'):
      X, y = [], []
      for i in range(len(df) - seq_len):
          X.append(df[feature_cols].iloc[i:i+seq_len].values)
          y.append(df[target_col].iloc[i+seq_len])
      return np.array(X), np.array(y)
  ```

- **GPU Requirements**: A single modern GPU (e.g., RTX 3060) is sufficient; training on CPU will be considerably slower.
- **Expected Training Time**: Roughly **5‑15 minutes** per walk‑forward iteration on a GPU for the chosen architecture.
- **Reproducibility**: Set random seeds (`numpy`, `tensorflow`/`torch`, Python `random`). Log hyper‑parameters and results.

## 6. Failure Diagnostics

- **If LSTM does not beat Random Walk**:
  - Check **over‑fitting**: training loss much lower than validation loss.
  - Verify **feature scaling** – unscaled inputs can hinder learning.
  - Examine **class imbalance** – may need stronger weighting or resampling.
  - Review **look‑back window** – too short may miss regime patterns; too long may dilute signal.
- **Regime‑Specific Performance**:
  - Split evaluation by market regime (high volatility vs low volatility) to see where the model struggles.
  - Consider adding regime‑indicator features.

---

## 7. Deliverables

- This document (`research_output.md`).
- Suggested code snippets (see Section 5) for data loading, sequence generation, and model definition.
- A clear roadmap for experimental runs and performance reporting.

_Prepared based on the specifications in `ORDER_5_PROMPT.md`._

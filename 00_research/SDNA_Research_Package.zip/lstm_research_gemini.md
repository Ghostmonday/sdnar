# S-DNA Deep Learning Baseline Research: LSTM

## 1. ARCHITECTURE SPECIFICATION

### Input Features

To ensure stationarity and predictive power, we generally avoid raw prices in favor of stationary transforms.

- **Log Returns:** $r_t = \ln(P_t / P_{t-1})$. This is the primary input feature ensuring stationarity.
- **Volatility:** The `volatility` column provided in the datasets.
- **Lagged Labels:** Including previous classes (if known/available at inference time) can be predictive if volatility clustering exists.
- **Normalization:** Z-score normalization (Mean=0, Std=1) for all inputs is critical for LSTM convergence.

### Sequence Length (Lookback Window)

- **Primary Recommendation:** **60 days** (approx. 1 trading quarter).
- **Secondary Search Range:** [20, 60, 120].
- **Rationale:** Financial markets often have quarterly cycles. 20 days captures short-term momentum, while 120 days captures medium-term trends.

### Network Structure

- **Hidden Layers:** Start simple. **1 to 2 LSTM layers**.
- **Units:** **64 to 128 units** per layer.
- **Activation:** `tanh` (internal LSTM state) and `sigmoid` (gates) are standard.
- **Output Layer:**
  - **Classification (Preferred):** 3 units (for -1, 0, 1) with **Softmax**. Matches Triple-Barrier labels.
  - **Regression:** 1 unit with **Linear** activation (if predicting raw return).

### Regularization

Financial data is extremely noisy; regularization is non-negotiable.

- **Dropout:** High rates are necessary. **0.2 to 0.5** after LSTM layers.
- **L2 Regularization (Weight Decay):** Use $1e-4$ to $1e-5$ in the optimizer.

## 2. TRAINING PROTOCOL

### Data Split

**Strict Time-Series Split** (Never shuffle).

- **Train:** First 70% of indices.
- **Validation:** Next 15% (Hyperparameter tuning).
- **Test:** Final 15% (Final evaluation).

### Optimizer & Loss

- **Optimizer:** **AdamW** (Adam with decoupled Weight Decay). Learning Rate ~$1e-3$.
- **Loss Function (Classification):** `CrossEntropyLoss`.
  - **Critical:** Apply **Class Weights** inverse to class frequency to handle the likely imbalance of the '0' class.
- **Loss Function (Regression):** `MSELoss`.

### Training Loop

- **Batch Size:** 32 or 64.
- **Epochs:** Max 100.
- **Early Stopping:** Monitor Validation Loss. Patience = 10 epochs. Restore best weights.

## 3. WALK-FORWARD VALIDATION

To truly validate robustness against regime changes:

1.  **Expanding Window:** Train on initial window $T$.
2.  **Predict:** Forecast $T+1$ (e.g., next month).
3.  **Expand:** Add $T+1$ data to Train.
4.  **Retrain/Refit:** Update model weights.
5.  **Aggregate:** Collect all out-of-sample predictions to form a full backtest vector.

## 4. EVALUATION FRAMEWORK

### Metrics

- **Classification:**
  - **Precision, Recall, F1-Score:** Per-class (-1, 0, 1).
  - **Confusion Matrix:** Check for mode collapse (e.g., model only predicting '0').
- **Regression:**
  - **RMSE:** Compare against the Random Walk RMSE (SPY: 4.54, BTC: 1322).
  - **Directional Accuracy:** (Correct Signs / Total Predictions). Goal > 50%.

### Statistical Significance: Diebold-Mariano Test

- **Hypothesis:** Is LSTM error significantly lower than Random Walk error?
- **Metric:** DM Statistic.
- **Threshold:** p-value < 0.05.
- **Python:** Use `dieboldmariano` package or implement the DM statistic formula manually.

## 5. IMPLEMENTATION GUIDANCE

### Framework: PyTorch

Standard in research for control over data loaders and custom loss functions.

### Sliding Window Generator

Efficiently creating sequences is key.

```python
def create_sequences(features, targets, seq_len):
    xs, ys = [], []
    for i in range(len(features) - seq_len):
        x = features[i:i+seq_len]
        y = targets[i+seq_len]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)
```

### Hardware

- **GPU:** Optional but recommended for Walk-Forward loops which require many retraining cycles.
- **Time:** Single fold training should take < 5 minutes for provided datasets (SPY/BTC).

## 6. FAILURE DIAGNOSTICS

If (and when) LSTM fails to beat the Random Walk:

1.  **Check Signal-to-Noise:** The "0" label might be too dominant. Try strictly identifying volatility regimes rather than direction.
2.  **Lookback Window:** Is 60 days too long? Markets change fast. Try 10 or 20.
3.  **Stationarity Violation:** Ensure _all_ inputs are stationary. Raw prices will likely cause the model to act as a naive random walk (predicting $P_t \approx P_{t-1}$).
4.  **Overfitting:** If Train Acc >> Val Acc, double the Dropout.
